a collection of fragements on *Critical Instruments*
