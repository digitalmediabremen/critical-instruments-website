# Next Steps

- [ ] finish [Critical Instruments / Research Project Architecture](https://docs.google.com/document/d/1ZnUVvJqBd4P9WGZrLqU-GowFVfFu1YBRf5dpSftNpqk/) ( until 2023-03-23 )
- [ ] submit [FuE(2023-04) Critical Instruments](https://docs.google.com/document/d/1MrpfAzoJEeDv-ftJ4uQ_ZiVi2Wa0m5hmFYpAp6ItH7o/) ( until 2023-04-01 )
- [ ] establish research network ( aka meet with ethonography/sociology ) (2023-04)
- [ ] submit VWSt application in autumn ( maybe 2023-10 )