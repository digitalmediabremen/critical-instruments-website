# Abstract / Ics

Critical Instruments opens spaces and moments for being critical about the instruments we use, consume/purchase and create. The ways they exist… CI Reflects on the ontological questions about instruments. 

Critical instruments is electronic anarchy, goes against unnecessary electronic production chains.

We use creation strategies, in concordance with a local reality, using local technologies. We teach, we learn, we share and create community around the critical thinking and creation of instruments, technologies and tools. Critical instruments foments technological Autonomy.  

Music is the medium. Music travels and mixes, like food but the ingredients are the rhythms, the melodies, the instruments. Unlike politics or economics, music has unified cultures, has create subcultures, empowered them, and emancipated them. 
 
the creation of Instruments is a way to understand technology, and digital electronic technologies.

CI is Utopian
 
But do we use critical theory to think about instruments? ( feminisms, decolonial studies, gender studies…) who do we challenge power structures? 
Is it open-source an answer to all of these?  is it reusing? recycling?

---

## what/why interests me

Reflect on the ways we create and use electronics / digital electronic musical instruments
Building musical instruments
making music
Performing 
Think about new way of developing/approaching electronics
Rethink about the materiality of the Instruments 
to know what is the future of electronic music Instruments.

---

### Do we create research instruments?

---

### Wish list:

- Meetings (in radio) tha produce podcast
- residencyssss!!!1
- Symposiums - Bring artists from all over the world, to think and talk about new approaches on electronics through music and sound instruments
- Create utopian sustainable futures
- Build sound/music instruments Make music
- Work with community / Create a community or empower a community.
- Residencies
- Create a Manifesto of Critical instruments
- Create something open source
- Reuse materials, work with electronic recycling
- Experiments with electronics
- Create interdisciplinary meetings or encounters, for example with philosophers and social scientist to think about the musical electronic creation




