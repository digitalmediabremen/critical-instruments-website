# Abstract / Bremen-Fond-Application

*Critical Instruments* is designed as an artistic-creative research project in which the production and use of electronic-digital musical instruments is explored as a form of critical thinking and acting ( *Critical Design* ).

At the core of the research project *Critical Instruments* is the assumption that music is a social, empowering and participatory phenomenon. Further, *Critical Instruments* is based on the assumption that music can serve as a *catalyst* for aesthetic and social transformations ( e.g. subcultures ). However, in contrast to what is commonly seen, the project attempts to detach the design, production, exploration, testing and use of musical instruments ( including their composition ) from the *sandbox* of music ( e.g. concert hall or music school ) and explore it as an *active* social *agent*. A special focus is not only put on music itself and making music as an activity, but deliberately extended to the invention and production of ( electronic and digital ) musical instruments. 

As a creative-artistic project, the production of artifacts, the experimental research as well as the application in situ play a central role ( *Artistic Field Research* ). For this reason, forms of *field research* are also to be developed or further developed in the project. Cooperations with the social sciences and ethnology are therefore definitely sought.

Even if music and the making of music is self-sufficient, the transferability of findings to other areas of life and contexts plays a role in this research project, so that the following questions are the subject of the project:

- How can the *local* development and use of musical instruments structure a community ( *community* )? How can social challenges be overcome in this way ( *design for change* )? How can forms of shared participation be realized in this way ( *queer use* + *sharing community* )?
- How can products and services in the *public domain* ( *Open Source* ) be created in a participatory way ( incl. *Non-Profit Products* )?
- Which musical forms emerge beyond *traditional* forms of reception and production, enabled by networking and digitalization ( e.g. *Internet of Things* )?

The research project *Critical Instruments* emerges from a series of smaller activities, research and works ( see *Klangstrom* and *The Dynamic Archive* ).

%%Translated with www.DeepL.com/Translator (free version)%%