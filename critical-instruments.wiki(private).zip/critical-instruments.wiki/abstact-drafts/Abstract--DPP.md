# Abstract / DPP

@note(@dpp, *an attempt but still very stiff*)

the project *critical instruments* aims to research and apply the transformational potential of electro-digital music and instrument build in (local) communities. 

( about the method toolkit ) the project aims to bring together the fields of design, music, ethnography(-logy?) and sociology in order to develop practices in between the fields ( @add(*Critical Design Ethnography*, Critical Thinking) ).

the project is structured in 3 phases: the first phase is characterized by the development of a *field kit* in collaboration with a peer or expert community, the second phase by an application of the results of the first phase in a *field research* scenario in a *local* community. in the third phase the results of the second phase will be *generalized* and dissiminated(@TODO(!?!)).

%%@note( i am just realizing that the CI project is *bigger* or more generic then the application for the transformation grant. i think we should frame it in a way that CI is "an artistic research project that uses methods of *Critical Design Ethnography* (@maybe frame this a bit more *pompous*) to justaposes music, music making and instrument bulding ( focus on electro/digital ) as a device for inquiry in order to work with all sorts of communities. ( blääh this is not well phrased but in essence correct i think)" )%%

## what is the core of the Critical Instrument research project?

*Critical Instruments* (CI) is an artistic research project in which the production and use of musical instruments is explored as a form of inquiry, critical thinking and acting. The project is concerned with the juxtaposition of artistic and design strategies, music and communities.

---

## some random notes, methods and keywords that could go into the abstract

- Critical Design Ethnography
- Field Kits
- Transformation ( of what ) explored/documented/accompanied through music/music-making/instrument-building
- what people are addressed … as researchers, research subjects
- the instrument ( "music is about sound but also about instruments" see tuhkanen quote )

- what musicians and what artists are we looking at

### quotes "why music and musical instruments?"

> ”In a world dominated by the visual, could contemporary resistance be auditory?”
> - Brandon LaBelle

> ”As a relational art practice music is seen as a social formation not only around sounds, but also around instruments. […] to critically think about instruments, what they are and how they are and can be instrumentalized for interrupting and changing social norms and habits in permanent ways as material sonic artefacts.”
> - Timo S. Tuhkanen

### some sentence about *critical design ethnography* from chatGPT that might be borrowed 

> Critical Design Ethnography is a multidisciplinary approach that combines elements of critical design and ethnography to create a design-based critique of technology and society. This approach uses design as a means to critically reflect on social, cultural, and political issues, as well as to speculate on alternative futures. The goal of critical design ethnography is to understand how technology and society interact, and to encourage the public to think critically about the role of technology in their lives. This approach typically involves the collection of data through observation, interviews, and other methods of ethnographic research, followed by the creation of designed artifacts that reflect on and question the implications of technology and its impact on society.

interesting but there is definitely a feedback cycle missing for our purposes i.e first ethnography and then designing the artifacts implies a hierarchy that is not wanted IMHO.


### reworking some sentences on *Critical Design*

CI goes beyond the creation of *aesthetically pleasing* or *functional* music and musical instruments. Instead, it uses music and musical instruments as a means to question and critique the social, cultural, and political implications of technology and design. It seeks to challenge existing power structures and to provoke thought and discussion about the future impact of technology on society. CI involves the creation of imaginary or speculative music and musical instruments that present alternative scenarios or visions of the future, often in an attempt to stimulate discussion and reflection on important social, ethical, and political issues. This approach seeks to challenge dominant narratives and to offer alternative perspectives on the role of technology and design in society.
