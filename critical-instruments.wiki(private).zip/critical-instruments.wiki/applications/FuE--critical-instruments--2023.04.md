# FuE / Critical Instruments / 2023.04

ATM i see two options here:

1. going the south scandinavian farm and explore in a very secluded place some of the proposed methods of CI
2. take the exsiting klangstrom infrastructure and facilitate a dedicated workshop with a specific group of people or community ( e.g DM student engage with kindergarden people )
