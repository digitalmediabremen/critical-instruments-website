# Antrag_Bremen-Fonds / Prof. Dennis P Paul / Critical Instruments (20221027)

- Name Antragsteller*in: Prof. Dennis P Paul
- Kurztitel des Antrags: Critical Instruments
- Name der Hochschule/Fachbereich/Fakultät: Hochschule für Künste Bremen, Fachbereich Kunst + Design

## 1 Projektidee

Ziel des Projekts ist die künstlerisch-gestalterische Erforschung des transformativen, aesthetischen und sozio-kulturellen Potentials und Repertoires, welches aus der Entwicklung, Produktion und Nutzung neuer digitaler und elektronischer Musikinstrumente entsteht.

## 2 Zusammenfassung

*Critical Instruments* ist als ein künstlerisch-gestalterisches Forschungsprojekt angelegt in dem das Herstellen und Nutzen von elektronisch-digtialen Musikinstrumenten als eine Form des kritischen Denkens und Handelns erforscht wird ( *Critical Design* ).

Im Zentrum des Forschungsprojekts *Critical Instruments* steht die Annahme, dass Musik ein soziales, ermächtigendes und partizipatives Phänomen ist. Weiter basiert *Critical Instruments* auf der Annahme, dass Musik als *Katalysator* für ästhetische und gesellschaftliche Transformationen dienen kann ( zB Subkulturen ). Aber anders als gemeinhin gesehen versucht das Projekt das Gestalten, Herstellen, Erforschen, Erproben und Nutzen von Musikinstrumenten ( inklusive ihrer Komposition ) aus der *Sandbox* der Musik ( zB Konzertsaal oder Musikschule ) zu lösen und es als einen *aktiven* gesellschaftlichen *Agenten* zu erforschen. Ein besonderer Fokus wird hierbei nicht nur auf die Musik ansich und das Musizieren als Aktivität gelegt, sondern ganz bewusst um das Erfinden und Herstellen von ( elektronischen und digitalen ) Musikinstrumenten erweitert. 

Als ein gestalterisch-künstlerisch angelegtes Projekt, erhält die Produktion von Artefakten, das experimentelle Erforschen, sowie die Anwendung in situ eine zentrale Rolle ( *Artistic Field Research* ). Aus diesem Grund sollen in dem Projekt auch Formen der *Feldforschung* entwickelt bzw weiterentwickelt werden. Kooperationen mit den Sozialwissenschaften und der Ethnologie werden daher unbedingt angestrebt.

Auch wenn die Musik und das Machen von Musik sich selbst genügt, spielt die Transferierbarkeit von Erkenntnissen auf andere Lebensbereiche und Kontexte in diesem Forschungsprojekt eine Rolle, so dass die folgenden Fragen Gegenstand des Projekts sind:

- Wie kann die *lokale* Entwicklung und Nutzung von Musikinstrumenten eine Gemeinschaft ( *community* ) strukturieren? Wie können so soziale Herausforderung bewältigt werden ( *Design for Change* )? Wie können so Formen der gemeinsamen Teilhabe realisiert werden ( *Queer Use* + *Sharing Community* )?
- Wie können Produkte und Services in der *public domain* ( *Open Source* ) partizipativ entstehen ( inkl. *Non-Profit Products* )?
- Welche musikalischen Formen entstehen jenseits *tradierter* Rezeptions- und Produktionsformen, ermöglicht durch Vernetzung und Digitalisierung ( zB *Internet of Things* )?

Das Forschungsprojekt *Critical Instruments* geht aus einer Reihe von kleinteiligeren Aktivitäten, Forschungen und Arbeiten hervor ( siehe *Klangstrom* und *The Dynamic Archive* ).

## 3 Beschreibung des Vorhabens

### 3.1 Ziel des Impulsantrags

Der Impulsantrag verfolgt zwei Ziele. Einerseits den Aufbau eines Netzwerks aus regionalen, nationalen und internationionalen Partnern und andererseits die Recherche und Erarbeitung von Forschungsanträgen.

#### Aufbau eines Forschungsnetzwerks

Es existieren bereits eine Reihe von aktiven Verbindungen zu anderen Forschenden und Einrichtungen. Der Impulsantrag soll dazu dienen die Verbindungen, gerade auch die überregionalen bzw internationalen, entweder zu konkretisieren oder anzubahnen.

#### Forschungsanträge

Neben dem Aufbau eines Forschungsnetzwerks dient der Impulsantrag, in der Hauptsache, der Vorbereitung und Erarbeitung eines Forschungsantrags bei der VolkswagenStiftung. Hierzu bedarf es neben der Formulierung des eigentlichen Antrags vor allem auch umfangreicher Recherchearbeiten, sowie der Dokumentation und Archivierung von Vorarbeiten zur Einbindung in den Antrag.

Ergänzt wird die Erarbeitung des Forschungsantrag bei der VolkswagenStiftung um eine Recherche zu weiteren Fördermöglichkeiten.

### 3.2 Umsetzung des Vorhabens

Aufgrund der kurzen Zeit werden, mit Ausnahme des Besuchs an der *University of Groningen*, alle Anbahnungsaktivitäten online bzw virtuell bis zum Ende des Jahres stattfinden. Die Dokumentations-, Archivierungs- und Recherchearbeiten werden unmittelbar nach Bewilligung gestartet und laufen bis zum Ende des möglichen Finanzierungszeitraums ( Dezember 2022 ).

Die Verfassung des Antrags bei der Volkswagenstiftung wird in zwei Phasen stattfinden. Eine erste vorbereitende Phase, die von Antragsbewilligung bis Ende des Finanzierungszeitraums läuft und eine zweite finalisierende Phase die von Januar 2023 bis Ende März 2022 läuft. Die erste Phase schliesst mit der Einreichung einer *Antragsskizzen* und die Zweite mit der Einreichung eines *Vollantrag* bei der VolkswagenStiftung ab.

## 4 Kooperationen

Eine Kooperation mit den folgenden Personen bzw Institutionen soll vertieft bzw entwickelt werden: 

- Hochschule für Künste: Prof. Peter von Maydell ( Interface Design ) und Prof. Dr. Barbara Stiller ( Elementare Musikpädagogik, Instrumental- und Vokalpädagogik, Musikvermittlung ) "In Anwendungs- und Forschungsprojekten in dem zusammen mit der Firma Hohner ein *Akkordeon für Kinder* und *Neue Mundharmonikas* entwickelt wurden, wurde bereits fachbereichsübergreifende und interdisziplinär zusammen gearbeitet."
- Universität Bremen: Institut für Ethnologie und Kulturwissenschaft "Bestehende Verbindungen mit dem Institut aus dem Projekt *The Dynamic Archive* sollen geprüft werden und ggf im Rahmen eines gemeinsamen *Feldforschungsprojekts* entwicklet werden."
- Jacobs University Bremen: Prof. Dr. Klaus Boehnke ( Social Science Methodology )
- University of Groningen ( Niederlande ): Prof. Dr. Ann-Sophie Lehmann "Im Rahmen des PhD Programms der Hochschule für Künste gibt es bereits eine Kooperation. Im Rahmen des Impulsantrags wird geprüft inweit eine Involvierung von PhD Kandidaten mit Arbeiten mit thematischem Bezug möglich ist."
- Emily Carr University ( Kanada ): Prof. Dr. Garnet Hertz ( Studio for Critical Making, Faculty of Design and Dynamic Media ) "Aufgrund von thematischen und inhaltlichen Bezügen wird im Rahmen des Antrags eine Kooperation entwickelt und ausgerarbeitet."

## 5 Kosten

### 5.1 Kostenübersicht

```
|  # | BEANTRAGTE MITTEL                                            | BETRAG   |
|----|--------------------------------------------------------------|----------|
|  1 | Reisegeld ( Bremen > Groningen )                             |  350,00€ |
|  2 | Studentische Hilfsk. ( Dokumentation + Archivierung, 2×40h ) | 1000,00€ |
|  3 | Werkvertrag für Recherche- + Dokumentationsunterstützung     | 1500,00€ |
|  4 | Werkvertrag für Recherche- + Antragsunterstützung ( Extern ) | 2100,00€ |
|    | GESAMT                                                       | 4950,00€ |
```

### 5.2 Begründung

#### 1. Reisegeld

Reisekosten für einen Besuch von *Prof. Dr. Ann-Sophie Lehmann* an der *University of Groningen* per Bahn.

#### 2. Studentische Hilfskraft

Finanzierung einer studentischen Hilfskraft zu 2×40h. Die Aufgabe der studentischen Hilfskraft ist es exisiterende Vorarbeiten zu dokumentieren und zu archivieren, so dass sie im Antrag für die VolkswagenStiftung verwendet werden können.

#### 3. Werkvertrag für Recherche- + Dokumentationsunterstützung

Finanzierung einer Person ( aus dem Kreise der PhD Kandidaten; hier gibt es bereits themische Bezüge ) für die Recherche von relevanten weiteren Fördermöglichkeiten, die Ausarbeitung einer Bibliografie, sowie die Generierung von Dokumentationsmaterialien aus bereits exisitierenden Vorarbeiten und der Erstellung neuer Materialien.

#### 4. Werkvertrag für Recherche- + Antragsunterstützung

Finanzierung einer Person für die Recherche von relevanten weiteren internationalen Fördermöglichkeiten, sowie massgebliche Unterstützung bei der Erarbeitung des Antrags für die VolkswagenStiftung.

## 6 Zusätzliche Angaben zur Ausschreibung, wenn Sie die Vorbereitung eines Drittmittelantrages planen

Es ist ein Drittmittelantrag bei der VolkswagenStiftung geplant. Für das Vorhaben wurde die Förderlinie *Pioniervorhaben – Gesellschaftliche Transformation* ( siehe https://www.volkswagenstiftung.de/unsere-foerderung/profilbereich-gesellschaftliche-transformationen ) ausgesucht. Das Förderangebot teilt sich in zwei Stufen *Antragsskizzen* und *Vollantrag*. 

## 7 Literaturverzeichnis

- Prof. Dr. Andrea Sick + Prof. Dennis P Paul: The Dynamic Archive, https://www.thedynamicarchive.net/
- Prof. Dennis P Paul: Klangstrom, https://klangstrom-for-arduino.dennisppaul.de/ ( in Zusammenarbeit mit Jacob Remin )
- Anthony Dunne & Fiona Raby: Speculative Everything: Design, Fiction, and Social Dreaming, MIT Press, 2013 
- Mary Flanagan: Critical Play: Radical Game Design, MIT Press, 2009
- Sarah Ahmet: Queer Use, Duke University Press, 2019

## Anlagen

### A) Tabellarischer Lebenslauf

siehe Anhang
