## Link to the editable document on Google docs: 

- [Filled form with questions and answers (Preliminary)](https://docs.google.com/document/d/1BUUX8HYz4i5RaBkS6czV6v1T7GxwHIlC3BiX_x1TcwQ/edit)

# Title of project: Title of project

- Main applicant: academic title, forename, surname
- Institution: please enter the research institution of the main applicant    
- Overall sum applied for (EUR): overall sum in EUR      
- Project duration applied for: year(s)     

## Description of research gap:

> Please describe your identified research gap and your research question(s). Which (largely) under researched and/or emerging societal transformation process do you focus on? (max. 300 words).

## Description of project:

> Please describe which pioneering methods and theory concepts are used to generate transformational knowledge and please describe your work packages and mile stones. Please give also information why this project can only be funded by Volkswagen Foundation and not by any other funding organization. Images can be included below (max. 700 words).

## Consistency with funding program:

> Please explain why your project matches the aims of the funding program. You may address several aims of the program (see information for applicants, max. 150 words).

## Scaling and impact:

> Please explain how your project results and experiences will be translated into concrete recommendations for actions and how you will contribute to their implementation. How will you scale your project results and which impact do you expect with regard to your own and other academic disciplines, partner institutions, societal stakeholder groups, policy actors etc.) (max. 300 words).

## Involved persons/institutions:

> Please list all involved partners and institutions with whom/which you will conduct this project (w do not need any letters of interest at this stage). Please describe the research focus/key activities of your partners in two to three sentences and please explain shortly how you will collaborate (max. 300 words for description of key activities and collaboration).

## Budget outline: 
> Please describe in a few bullet points which costs are needed for your project, e.g. personnel costs, workshop costs, travel expenses). A detailed breakdown of all costs is only needed for the second application phase (invitation to submit a full proposal).

## Possible challenges and reflection of research process:
> Pioneers take risks. Please list possible challenges which you expect and please address possible scientific critique with regard to your project. Which impact will your results possibly have on the constitution of societal transformation processes? Please reflect on your planned research process. (max. 300 words).


## Images (optional):
> You may integrate up to two images here. 



