# Funding

- [VolkswagenStiftung](https://www.volkswagenstiftung.de) see also [google drive](https://docs.google.com/document/d/1clbFGEMov2TdR4DgkRvtAcmblPLnMnrG8zPFHKSq4pU)
- [New European Bauhaus](https://new-european-bauhaus.europa.eu/get-involved/funding-opportunities_en)
    - Mobilising EU programmes for the transformation of places on the ground (2023-2024) :: Fully dedicated or contributing to the New European Bauhaus calls for proposals aiming at supporting the concrete transformation of the built environment and associated lifestyles at local level.
    - Mobilising EU programmes for the [transformation of the enabling environment for innovation](https://new-european-bauhaus.europa.eu/get-involved/funding-opportunities/transformation-enabling-environment-innovation-calls-2023-2024_en) (2023-2024) :: Fully dedicated or contributing to the New European Bauhaus calls for proposals aiming at supporting innovation aimed at integrating sustainability, inclusion, and aesthetics in new solutions and products.
    - Mobilising EU programmes for the diffusion of new meanings (2023-2024) :: Fully dedicated or contributing to the New European Bauhaus calls for proposals aiming at facilitating a process of questioning our perspectives and mind-set around the values of aesthetics, sustainability and inclusion.


