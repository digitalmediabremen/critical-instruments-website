# Keywords

- field kit
- critical …
    - [[Critical-Design-Ethnography]]
    - [[Critical-Making]]
    - [Critical Engineering](https://criticalengineering.org/de)
- [New European Bauhaus](https://new-european-bauhaus.europa.eu/index_en) ( "… initiative that connects the European Green Deal to our living spaces and experiences" )
- proxy/surrogate ( why music? why instruments? both can also be seen as *neutral* grounds as sandboxes as concepts that stand for something else e.g society )
- catalyst ( i.e music and its periphery can also be the trigger for transformation of e.g social norms )