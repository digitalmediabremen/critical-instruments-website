# Reading List

- Anthony Dunne & Fiona Raby: Speculative Everything: Design, Fiction, and Social Dreaming, MIT Press, 2013 
- Mary Flanagan: Critical Play: Radical Game Design, MIT Press, 2009
- Sarah Ahmet: Queer Use, Duke University Press, 2019
- ( [Critical Theory](https://en.wikipedia.org/wiki/Critical_theory) )
- ( [Bruno Latour](https://de.wikipedia.org/wiki/Bruno_Latour) )
- ( [Timothy Morton: Hyperobjects](https://en.wikipedia.org/wiki/Timothy_Morton) )
- Brandon LaBelle: Sounds and Emergent Forms of Resistance