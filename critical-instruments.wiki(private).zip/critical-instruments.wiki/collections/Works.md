this is a list of works that somehow relate to the *Critical Instrument* (CI) project. the works are divided into two categories:

- works that have been produced by *us* or we were involved in in some other way ( e.g as professors, lecturers, or supervisors )
- works done by others that resonate well with what the *Critical Instrument* project

## us

- [Dennis P Paul + Jacob Remin: Klangstrom](https://dennisppaul.de/klangstrom), 2022 #infrastructure
- [Dennis P Paul: Wellen](https://dennisppaul.de/wellen), 2021 #infrastructure
- [Dennis P Paul: INFRASTRUCTURE](https://dennisppaul.de/infrastructure), 2020 #infrastructure
- [Dennis P Paul: NMI-010 A Computer Keyboard Instrument](https://dennisppaul.de/nmi-010-a-computer-keyboard-instrument.html), 2017 + [Dennis P Paul: NMI-011 A Computer Mouse Instrument](https://dennisppaul.de/nmi-011-a-computer-mouse-instrument.html), 2018 #musicalinstrument
- [Dennis P Paul: NMI-002 An Instrument for the Sonification of Everyday Things](https://dennisppaul.de/an-instrument-for-the-sonification-of-everyday-things), 2012 #musicalinstrument
- [jacob remin + jakob bak + dviid gauthiier: cheap fat and open](https://vsionhairies.info/), 2010 and kind of ongoing forever

### students

- [Felix Fisgus: Fizzi](https://felixfisgus.de/work/010_fizzi), 2018 #community #musicalinstrument
- [Felix Fisgus: Gammaphon](https://felixfisgus.de/work/001_gammaphon), 2016 #musicalinstrument

## others

- [Garnet Hertz: Disobedient Electronics](http://www.disobedientelectronics.com/), 2016 #book
- [Jatiwangi Art Factory](https://documenta-fifteen.de/en/lumbung-members-artists/jatiwangi-art-factory/), Documenta 15 @cqx931(a project with strong community engagement and empowerment, musical instrument making, just not so digital)
- [Common Grounds, Kerstin Ergenzinger](https://wiki.theater.digital/projects:commongrounds:start) @cqx931(a sound project that engages with the climate change as an urgent issue, it's more about the art & sience rather than social, but overall very nice research documentation and maybe it can be a good reference for that purpose)
@add(explanation of why these projects resonate with CI)
