
# [Hackers & Designers](https://www.hackersanddesigners.nl/)

from anja groten’s PhD thesis defense announcement:

> The main thesis of Groten’s research is that conventional design vocabularies cannot sufficiently express and account for collectivities’ resistance to fixation and stabilization. According to Anja Groten, collective design challenges notions of individual authorship, differentiations between disciplines, product and process, user and maker, friendship, and work relations. While collectives not only shape particular affiliations, design approaches, and aesthetics, they also require perspectives on working and designing together that resist a progress-based understanding of a design process.
