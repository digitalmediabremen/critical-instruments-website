# Critical Instruments / VWSt / Abstract

[[criticalinstruments-abstract]]

"our take on the project in regards to the *Transformation* call is that we want to explore the transformative potential of music and musical instruments in regards to local communities. we want to identify a community and their people ( not just any community but rather one that has some sort of relation to the idea of making ), to then work with them in order to instigate change in the forms of new practices, new values or new narratives."

- in regards to the *Transformation* call we will focus on *Open Source Community(+Product) Development*
- our goal is to practically work with local communities
- what about the the *making* aspect? empowering people to become craftspersons again?
- research ( project ) question: how can a non-need/non-profit driven domain ( i.e music ) contribute to the development of local communities + local production?
    - we want to ( practically ) explore and address this question

@add[[Place-as-a-Method]]
@add(the phases)

--- 

## Open Source Community + Product Development

- we want to bring back crafting ( production ) to a *local community*
- the musical instrument is just an occasion or placeholder here
- our goal is to (re)shape, revive or transform a *local* community. analyse, learn and extrapolate from this process in order to either go on to other communities or to transpose the findings to other fields
- what communities are we looking at? maybe to make it easy at first we should look at people who are somewhat *prone* to *Critical Instruments* such as hackers/mackers or children?
- instead of a purely verbal approach we propose a non-verbal, non-visual approach ( aka music )

### @REF New European Bauhaus

or maybe we should just look at [New European Bauhaus](https://new-european-bauhaus.europa.eu/get-inspired/inspiring-projects-and-ideas_en) ;)

### from NEB about page:

- **sustainability**, from climate goals to circularity, zero pollution, and biodiversity
- **aesthetics**, quality of experience and style beyond functionality
- **inclusion**, from valuing diversity to securing accessibility and affordability

### from "Localised and Urban Manufacturing, supporting creativity and the New European Bauhaus - HORIZON-CL4-2023-HUMAN-01-53"

> Decentralised, local and urban manufacturing is characterised by small, versatile factories, close to customers, and to highly qualified workers, where various types of customised products are produced in small series for the cost price of mass-produced products. This topic is intended to integrate the New European Bauhaus initiative into the development and implementation of the decentralised manufacturing vision.

https://new-european-bauhaus.europa.eu/get-involved/funding-opportunities/transformation-enabling-environment-innovation-calls-2023-2024_en