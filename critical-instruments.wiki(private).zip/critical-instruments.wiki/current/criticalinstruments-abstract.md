# Critical Instruments / Abstract

... an artistic-design research project exploring the making and using of musical instruments as a form of critical thinking and acting

The *Critical Instruments* research project (CI) is based on the assumption that music is a social, empowering and participatory phenomenon and that music can serve as a *catalyst* for aesthetic and social transformations ( e.g. subcultures ). However, in contrast to the common perspective on music, the project attempts to detach the design, production, exploration, testing and use of musical instruments ( including their composition ) from the *sandbox* of music ( e.g. concert hall or music school ) and explore it as an *active* social *agent*. A special focus is not only put on music itself and music making as an activity, but the focus is deliberately extended to the invention and production of ( electronic and digital ) musical instruments.

As an artistic-design research project, the production of artifacts, the experimental research, as well as the application *in situ* play a central role ( *Artistic Field Research* ) in this context. For this very reason, forms of *field research* are to be invented or further developed in this project. Cooperations with the social sciences, such as sociology, ethnography and ethnology, are explored, cultivated and collaboratively evolved.

Despite the fact that music and the making of music is *self-sufficient* the transferability of experiences, findings and methods to other contexts ( e.g. areas of life, culture and science ) play a vital role in this research project. The following questions are subject of this research project:

- *New Making* :: How can products and services in the *public domain* ( *Open Source* ) be created in a participatory way ( incl. *Non-Profit Products* )? How can old forms of *crafting* be revived and brought back into local production again ( *New European Bauhaus* )?
- *Empowering Local Communities* :: How can the *local* development and use of musical instruments structure a *community*? How can social challenges be overcome in this way ( *Design for Change* )? How can forms of shared participation be realized in this way ( *Queer Use* + *Sharing Community* )?
- *New Music* :: Which musical forms emerge beyond *traditional* forms of reception and production ( *Citizen Music* ), enabled by networking and digitalization ( *Internet of Things* )?
- *Alternative Narratives* :: How can music be a catalyst for identifying and crafting alternative narratives ( *Design as Inquiry* )? How can alternative futures and values be imagined through activites and experiences around music ( *Speculative Design* )?

The research project *Critical Instruments* emerges from a series of smaller activities, researches and works ( see e.g. [Klangstrom](https://klangstrom-for-arduino.dennisppaul.de/) and [The Dynamic Archive](https://www.thedynamicarchive.net/) ).

==@todo(elaborate on these topics)==

---

## a word on infrastructure?

- https://www.kulturverlag-kadmos.de/site/assets/files/3867/9783967500479-1.pdf
- 

## why music?

- music is social
- music is communication ( incl non-verbal + non-visual )
- music is self-sufficient
- music is a placeholder
- music is a catalyst
- music is proven to have transformative powers

### what are we talking about when we say *music*?

- from citizen science to citizen music ( "decentralize music": no concert halls, no specialist musicians )

## methods

### applied methodology/methods

- Critical Theory
- Crtiical Design Ethnography
- Autoethnography
- Speculative Design
- Critical Engineering
- Queer Use
- Field Research
- Participatory Design
- Artistic Research
- Transformation Research
- ( Open Source )

### our own process/method

1. identify a group of people or an area of interest ( that is not genuinely music related ) 
2. bring in or develop together with the people a musical constellation
3. use the constellation with or on the group 
4. reflect on the process

### examples of implememtations


---

