# 2023-01-25 workshop with VW Stiftung (VWS)

- förderangebot *Pioniervorhaben*
- förderstrategie: 
    - impulsgebend, 
    - risikobereit(!), 
    - grenzüberschreitung
        - über ländergrenzen, 
        - inter-+transdisziplinär, 
        - wissenschaft mit nicht-akademischen partner
- "förderung ungewöhnlicher forschungsideen"(!)
- "es geht um forschung über ABER auch um die umsetzung konkreter handlungsoptionen … eher ==keine grundlagenforschung=="
- handlungsempfehlungen ableiten und zur umsetzung beitragen
- einbindung nicht-akademischer stakeholder ist wichtig
- nicht nur das thema muss innovativ sein … sondern auch innovative methodiken
- "ein sehr kompetatives program … sie sind im wettbewerb mit sehr vielen anderen vorhaben … 4 sollen gefördert werden"
- "es wird nur gefördert was pioniergeist aufweist"
- "wir wollen selber herausfinden was die aktuellen themen sind … wo geht s gesellschaftlich hin?"
- "die entwicklung von ideen von handlungsoptionen"
- "auswahlprozess: mutli-perspektivische vorhaben setzen sich durch"
- "im vorschungsprozess die rolle der forschung stetig reflektieren"
- "zugelassen sind alle fachgebiete"
- "eine zentrale rolle für kultur-+geisteswissenschaften ist erwünscht"
- max 500.000,00 €
- @todo(kathrin fragen wegen equivalenz, ==antragsberechtig sind promovierte wissenschaftler==)
 
## verfahren

- zwei stufen
    - 1. skizze auf basis von *template*
    - 2. aufforderung zum vollantrag
- gutachter haben erfahrung in der transformationsforschung
- ==23.03.2023 skizzenstichtag==
- juni+juli: auffirderung antragsstellung
- sep+okt: einreichung vollantrag
- nov: beguachtung

 ## fragen von den anwesenden

- was soll in den vorantrag? keine genaue kostenplanung, keine schriftlichen vereinbarung mit kooperationspartner, die wichtige funktion des templates 
- gibt es ein vorgabe bzgl der partner. gibt es preferierte länder? nein soll aber zum vorhaben passen.
- wieviel leute reichen ein? es sollen nur 4 gefördert werden ( max 6 ), 5–10 kommen in die vollantragsstellung
- vergleich vorantrag+volantrag? umfang: 15–17 seiten antrag + anlagen ( für vollantrag )
- rollen von künstlerischer forschung? wird eher als methodik ( innerhalb der geisteswisschaften!?? ) als als eigene 
- sollen die *deliverables* auch innovativ sein? in der skizze soll es schon sehr detailiert sein. nur workshop A+B+C reicht nicht, es geht eher um das WIE wollen sie die workshops machen. klassische format ( e.g publikation ) kann es geben sollten aber nicht im forderung stehen
- in welcher sprache müssen die anträge eingereicht werden? skizze kann englisch oder deutsch sein, vollantrag muss englisch sein
- frage zur *innovation* ( methodik, thematik, … ) soll es in möglichst vielen dimensionen *neu* sein? "nicht jeder aspekt des antrags muss vollkommen ungewöhnlich sein", allerdings sollten methoden schon innovativ sein … auch wenn klassische methoden iO sind. am ende kommt es auf das *gesamtpaket* an.
- wer ist in der jury? "panel wird nach antragslage zusammen gestellt", jury hat trans-/inter-disziplinäre erfahrung
- ist das ausschöpfen der summe an bedingungen geknüpft? nein, dauer etecetera sollte nur sinn im bezug auf das projekt machen
- wie und wo soll das projektt risikofreudig sein? nicht nur in der grundlagenforschung sondern auch in der umsetzung. "nichts fördern bei dem man heute schon weiss was in 5 jahren schon raus kommt", "innerhalb des projektes sollen die handlungsoptionen entwickelt und umgesetzt werden"
- müssen die mittel in deutschland angesiedelt sein? es ist möglich mit internationalen partner. bewillung erfolgt an das institut ( i.e hfk ), danach kann es *weiterleitungsverträge* an internationale partner, reminder: in der skizze kann der kostenplan noch sehr grob sein
- gibt es einzelberatungen? man kann anfragen allerdings ist viel los und uU kommt es nicht zustande
- wie konkret soll die handlungsvorschläge werden? "sie machen ja schon aktivistische kunst …", aber *how does it scale?* lässt sich da was *generalisieren*.
- sind co-finanzierungen möglich? ja aber nicht so gerne gesehen da VWS schon hauptförderer sein möchte …
- können eigenen stellen finanziert werden? ja. es können alle art von stellen finanziert werden. im antragsportal gibt s info zu *personalmittelsätzen*
- ist lehrvertretung finanzierbar? ja *lehrstuhlvertretung* ist möglich.
- wann sollte das projekt starten? zu beginn nächsten jahres

---

## ==TODO==

- kathrin fragen wegen equivalenz *promovierte wissenschaftler*
- wir kommen eher von der anderen seite i.e *kreativität muss in den antrag* gegossen werden eher als *antrag muss kreativ* werden 
- "what is the *innovative* aspect about our project … in a few word"
- "we NEED to integrate kultur-+geisteswissenschaften into our project."
- "we need to research the apparently already defined term *transformation* + *transformationsprojekt* better" maybe a nice reasearch for qianxun+icaro?
- "how is what we do *generalizable*? ( this is an interesting collision of *world views* here )"
- neuer termin für workshop uU im februar?
- "what is our focus area in regards to transformation?"
    - @qianxun "focus on production?"
    - @dpp music as an as-old-as-humanity cultural practice
    - intermediate step: music as a method
    - rebuilding local communities ( after an industrial decline )
        - @qianxun "a way to (re)connect locals with a place"
    - change behavior of people *by example of* music

## questions?

- wie würden sie akademische künstlerisch-gestalterische forschung einordnen?
    - "zentrale rolle für kultur-+geisteswissenschaften"
    - noch in einer frühen phase und strukturieren unsere gruppe
    - was würden sie uns raten wie wir da priorisieren sollen?
    - nur uU erwähnen ( ethnologie + soziologie )


google translte to english follows:

2023-01-25 workshop with VW Foundation (VWS)

     funding offer for pioneering projects
     funding strategy:
         stimulating,
         willing to take risks(!),
         border crossing
             across national borders,
             inter+transdisciplinary,
             science with non-academic partners
     "promotion of unusual research ideas"(!)
     "it's about research BUT also about the implementation of concrete options for action ... rather ==no basic research=="
     derive recommendations for action and contribute to their implementation
     involvement of non-academic stakeholders is important
     not only the topic has to be innovative ... but also innovative methods
     "a very competitive program ... you are in competition with many other projects ... 4 should be funded"
     "Only what shows pioneering spirit is promoted"
     "we want to find out for ourselves what the current issues are ... where is it going socially?"
     "the development of ideas of options for action"
     "Selection process: multi-perspective projects prevail"
     "Constantly reflecting on the role of research in the research process"
     "All subject areas are permitted"
     "a central role for culture + humanities is desired"
     up to €500,000.00
     @todo(Kathrin ask about equivalence, ==PhD scientists are eligible to apply==)

procedure

     two steps
             sketch based on template
             prompt for a full application
     reviewers have experience in transformation research
     ==03/23/2023 sketch deadline==
     june+july: prompt to apply
     sep+oct: submission of full application
     new: appraisal

questions from those present

     what should be in the preliminary application? no precise cost planning, no written agreement with cooperation partners, the important function of the template
     Is there a requirement regarding the partner. are there preferred countries? no but should fit the project.
     how many people submit? only 4 should be funded (max. 6), 5-10 will be submitted for the full application
     compare pre-application+full-application? Scope: 15–17 pages of application + attachments ( for full application )
     roles of artistic research? is used more as a methodology (within the humanities!??) than as its own
     should the deliverables also be innovative? in the sketch it should already be very detailed. just workshop A+B+C is not enough, it's more about HOW you want to do the workshops. there can be a classic format (e.g. publication) but it shouldn’t be a requirement
     in which language must the applications be submitted? sketch can be in english or german, full application has to be in english
     question about the innovation (methodology, topic, ...) should it be new in as many dimensions as possible? "not every aspect of the application has to be completely unusual", however, methods should be innovative ... even if classic methods are OK. in the end it comes down to the total package.
     who is on the jury? "panel is put together according to the application situation", jury has trans-/interdisciplinary experience
     is there any conditions attached to exhausting the sum? no, duration etecetera should only make sense in relation to the project
     how and where should the project be willing to take risks? not only in basic research but also in implementation. "don't fund anything where you already know today what will come out in 5 years", "the options for action should be developed and implemented within the project"
     do the funds have to be located in germany? it is possible with international partners. Approval is given to the institute ( i.e hfk ), after which it can be forwarded to international partners, reminder: the cost plan can still be very rough in the sketch
     are there individual consultations? you can ask, but there is a lot going on and it may not happen
     How specific should the proposals for action be? "You already make activist art...", but how does it scale? Is there anything that can be generalized?
     is co-financing possible? Yes, but not so welcome because VWS already wants to be the main sponsor...
     can own positions be financed? Yes. all kinds of positions can be funded. In the application portal there is information about the personnel resource rates
     is teaching substitution fundable? Yes, it is possible to substitute a chair.
     when should the project start? at the beginning of next year

==TODO==

     kathrin questions about equivalence of post-doctoral scientists
     we tend to come from the other side i.e creativity needs to be poured into the proposal rather than the proposal needs to get creative
     "what is the innovative aspect about our project … in a few words"
     "we NEED to integrate culture+humanities into our project."
     "we need to research the apparently already defined term transformation + transformationsprojekt better" maybe a nice reasearch for qianxun+icaro?
     "how is what we do generalizable? ( this is an interesting collision of world views here )"
     new date for workshop maybe in february?
     "What is our focus area in regards to transformation?"
         @qianxun "focus on production?"
         @dpp music as an as-old-as-humanity cultural practice
         intermediate step: music as a method
         rebuilding local communities (after an industrial decline)
             @qianxun "a way to (re)connect locals with a place"
         change behavior of people by example of music

questions?

     how would you classify academic artistic and creative research?
         "central role for culture+humanities"
         still in an early phase and are structuring our group
         what would you advise us to prioritize?
         only mention if necessary ( ethnology + sociology )
    "how is what we do generalizable? ( this is an interesting collision of world views here )"
    neuer termin für workshop uU im februar?
    "what is our focus area in regards to transformation?"
        @qianxun "focus on production?"
        @dpp music as an as-old-as-humanity cultural practice
        intermediate step: music as a method
        rebuilding local communities ( after an industrial decline )
            @qianxun "a way to (re)connect locals with a place"
        change behavior of people by example of music

questions?

    wie würden sie akademische künstlerisch-gestalterische forschung einordnen?
        "zentrale rolle für kultur-+geisteswissenschaften"
        noch in einer frühen phase und strukturieren unsere gruppe
        was würden sie uns raten wie wir da priorisieren sollen?
        nur uU erwähnen ( ethnologie + soziologie )

