# 2023-02-23 Open Source Community Development

or

- Open Source Product Development
- World Building

## some notes from a conversation between jacob and dennis

![](2023-02-23--conversation.jpeg)
![](./resources/2023-02-23--conversation.jpeg)