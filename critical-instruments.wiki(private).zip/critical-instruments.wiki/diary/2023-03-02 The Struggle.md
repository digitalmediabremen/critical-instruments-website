# 2023-03-02 The Struggle

first of all, there is too much material floating around. i need to structure and reduce and focus:

there is a general project called *Critical Instruments* (CI) IMHO well described in the document [[Abstract--Bremen-Fond-Application]] and/or on the [CI website](https://digitalmediabremen.github.io/critical-instruments/):

> *Critical Instruments* is an artistic-design research project exploring the making and using of musical instruments as a form of critical thinking and acting.

then there is the application to the Volkswagen Stiftung (VWSt) where the research project is implemented in a series of actions looking at the transformation of *local communities* and how they can be empowered to develop narratives for possible and desireable futures through music, music making, and musical instrument build.