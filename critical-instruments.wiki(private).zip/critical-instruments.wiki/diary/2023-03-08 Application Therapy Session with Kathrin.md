# 2023-03-08 Application Therapy Session with Kathrin

- the *framework* is the methodology
- case studies, implementation
- *zusammenschau* of different methods, methodologies
- dreiklang: *praxis*, *methode* und *theorie*
- *nachgenerische nutzung* == post-rationalisierung ( same thing plus the *intuition* )
- also *erkenntnisoffen* and *trial and error* ( do not like this so much )
 
( reading the CI framework to kathrin )

- "detached from the sandbox …" :: 
    - change. describe the *problemhorizont: music is elitist, with gatekeeping, it created temples of reception* and then outline how we want to deviate from that i.e *Citizen Music* + bringing back the community-forming aspects of music
    - @icaro ==it is about access==
- @TODO(change _New Music_ to _Citizen Music_ )
- what is the main question or hypothesis of the project: "juxtoposition of certain design method and music+muscial-instruments"?
- "music historically has always served many function: community building, …"
- "imaginaries of making music" where is music made?
- **ACCESS** as a topic
- if CI can be applied almost everywhere, where is the it most interesting and potent? so that it does not become generic …
    - *navigate new technology* :: learning how to program, learning how to make
- "why is music a good proxy? explain!"
    - it is usually about a collective

## on transformation

- we are looking at local communities
- critical making of instruments
- we are building *community of practice*
- corneliuos castoriadis: "auto … nomy" we shape the society *social imaginaries* @REF
- it is about equal access and the "experience of"

---

## TODOs

- write about the interesting spots in the possibility space of design/art/making+musical-instruments?
- why is music a good proxy?
- research architexture/design: 
    - overall/leading question ( proxy, art/design/music+musical-instruments )
    - preliminary question ( "new making", "communities" ( or leading ) )
        - e.g what is community for us?
    - methods ( how are they used in out context? )