# Autoethnography

#method

> *Autoethnography* is a form of ethnographic research in which a researcher connects personal experiences to wider cultural, political, and social meanings and understandings. It is considered a form of qualitative and/or arts-based research.

from [Autoethnography@Wikipedia](https://en.wikipedia.org/wiki/Autoethnography)

i know it s a bit hot ATM ( including a hot *potato* ) however i think this method can be a good communicative segway to approach we *naturally* take or were taking already anyway.

on a sidenote, it s quite interesting how the authors of *Critical Design Ethnography: Designing for Change* ( see [[Critical-Design-Ethnography]] ) address a dilema that is true for this kind of ehtongraphy as well: "As design ethnographers, we move beyond being simply participant observers in that we are also change agents supporting local transformation … " ( p256 )