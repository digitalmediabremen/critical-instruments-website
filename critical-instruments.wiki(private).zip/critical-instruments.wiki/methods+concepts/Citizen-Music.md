# Citizen Music

in contrast to highly professionalized, centralized modus of music production and reception *Citizen Music* takes a different approach. it aims to decentralize music in a sense that it aims to revice ancient ideas of music making as a social or ritualistic gesture. it however defies *temples* of music reception ( concert halls ) and targets the everyday, the mondaine and the normal as the venue not just for music reception ( which is quite common ).

the term *Citizen Music* is inspired by the idea of [Citizen Science](https://en.wikipedia.org/wiki/Citizen_science). not only does it also aim at non-professionals and amateurs it also implies the communal agency that the term *citizen* is connotated with. *Citizen Music* thereby wants to draw attention to the fact that music *may* not only have socially postive effects but should actually actively *assume* the role of a social *amplifier*. like in *Citizen Science* collaborations or interactions with professional musicians may occur and are welcome but are not mandatory.

the main intention behind the term is to communicate the notion that music is something everyone is entitle to participate in and appreciated.