# Critical Design Ethnography

#method 

i have not read any of these papers yet, however, the idea of a juxatposition of *Critical Design* and *Ethnography* sounds interesting and relevant:

- [Critical Design Ethnography: Designing for Change](https://www.researchgate.net/publication/227874054_Critical_Design_Ethnography_Designing_for_Change)
- [Ethnography and Critical Design Practice](https://medium.com/@taylorlundeen/ethnography-and-critical-design-practice-6b40521e8e6d)
- [Critical Design Ethnography as Action Research](https://www.jstor.org/stable/3651406?seq=1#metadata_info_tab_contents) *a comment on [Critical Design Ethnography: Designing for Change](https://www.researchgate.net/publication/227874054_Critical_Design_Ethnography_Designing_for_Change)*

also see [google drive: Notes on Critical Design Ethnography](https://docs.google.com/document/d/1Hve5_H4_vD0AXzXg-nq_HZdd7TRt3cEtu61Wsv98aoI)

chatGPT says:

> Critical Design Ethnography is a multidisciplinary approach that combines elements of critical design and ethnography to create a design-based critique of technology and society. This approach uses design as a means to critically reflect on social, cultural, and political issues, as well as to speculate on alternative futures. The goal of critical design ethnography is to understand how technology and society interact, and to encourage the public to think critically about the role of technology in their lives. This approach typically involves the collection of data through observation, interviews, and other methods of ethnographic research, followed by the creation of designed artifacts that reflect on and question the implications of technology and its impact on society.