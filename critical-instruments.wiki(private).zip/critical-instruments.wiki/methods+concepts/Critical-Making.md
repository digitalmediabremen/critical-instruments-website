# Critical Making

> Critical making refers to the hands-on productive activities that link digital technologies to society. It was invented to bridge the gap between creative, physical, and conceptual exploration.

from [Critical Making @ wikipedia](https://en.wikipedia.org/wiki/Critical_making)

- "In 2014, Hertz founded "The Studio for Critical Making" at Emily Carr University of Art and Design as Canada Research Chair in Design and Media Arts."
- see also anja grote
