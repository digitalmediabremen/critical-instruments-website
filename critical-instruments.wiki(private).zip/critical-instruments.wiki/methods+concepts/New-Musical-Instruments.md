# New Musical Instruments

*New Musical Instruments* is a series of instruments that i have been working on since 2012.

> a series of musical instruments exploring interfaces and their implication by engaging with them in a musical fashion.

for sure this is a subset of the *Critical Instruments* research project.

## Notes on NMIs

- i am interested in musical instruments that on the one hand evade the idea of control to a certain extend but allow for some kind of unique precision ( instrument ).
- i think it is important that my instruments can be *learned* and explored but not necessarily fully understood.
- in a sense the mode of interaction with my instruments is metaphorical.