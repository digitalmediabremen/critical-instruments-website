# Non-Music Instruments

how where and what instruments start to blur the boundaries between music making and consuming? between gaming and playing music? etcetera 

i am thinking along the lines of [Non-Games](https://en.wikipedia.org/wiki/Non-game) here; videogames that are somewhat located in the genre but intentionally fail to subscribe to such ideas as winner-looser, points, clear structure or goals. similarily i think there exit non-music(al) instruments that are made for making sounds maybe even in a collaborative fashion but not immediately recognizable as musical instruments. maybe they would measure more then they make music and just sonified the measurements? maybe they do not facilitate immediate music making but stretch it over time or certain events.

note, this thought does not address the *other* instruments such as medical instruments or measuring instruments. the term *non-music* deliberately references music in a *negativform* ( as in counterpart or cast ).