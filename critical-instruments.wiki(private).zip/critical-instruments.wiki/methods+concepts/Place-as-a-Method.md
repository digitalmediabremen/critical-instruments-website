# Place as a Method

#method

all *human-crafted* places relate to the people that shaped and to those who use them. places tell a story about the people connected to them. therefore we use the concept of *places* in order to address certain communities or groups of people.

## The Places

- The Farm
- The Village
- The Factory ( or The Shipyard )
- The District
- The Church
- The Island
- The Kindergarden
