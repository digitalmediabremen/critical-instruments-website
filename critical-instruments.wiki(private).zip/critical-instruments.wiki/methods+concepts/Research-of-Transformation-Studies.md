## Definition

“Transformation research studies and supports fundamental change processes of societal systems towards sustainability from a scientific perspective. These research goals require both descriptive-analytical as well as transformative research approaches, which yield conceptual and actionable knowledge through trustworthy, transparent and reflexive re-search processes. The – complementary – research foci of transformation research in-clude the objects of transformation (what changes over the course of a transformation), the change dynamics of transformation processes and emerging transformation path-ways (how do transformation processes occur), and the drivers of transformation pro-cesses (by whom/how are transformation processes supported).”

## Goals

- on the one hand, it is dealing with transformations as research object – analysing, describing and explaining historical transformations and current change dynamics to increase our understanding of them as a knowledge base to support transformations towards sustainability. 
- On the other hand, it is about actively supporting such sustainability transformations.

## Research Methods

- Data generation – general: Participant observation, Research diaries...
- Data generation – interview: Expert interview...
- Data analysis – general: Case study, Literature analysis, Qualitative content analysis...
- Data analysis – actor analysis: Stakeholder- and actor anal-ysis, Social network analysis...
- Participatory Methods: Community of Practice, Hackathon...

## Asessing Criteria

![Criteria_for_assessing_potential_of_transformation](https://www.ecologic.eu/sites/default/files/publication/2021/2267_Criteria_for_assessing_potential_of_transformation.jpg)

## From Kathrin

"In general and historically, transformation studies developed in light of economics, politics and social studies need to combine theories and approaches when faced with the complex entanglement of the global markets, anthropocenic climate crisis, geopolitics and migration crises. Therefore, transformation studies have a focus on all aforementioned disciplines and usually look beyond a simple cause and effect analysis.

While some researchers focus on the year 1989, as a ceasuras of worldwide scale, some determine the start of massive transformations in wake of the digitalization.

Rather than giving you just a general explanation, it would be helpful to narrow down on a concentration, which the application will have, (such as digitalization, community-building on a communal level, global markets, designing for the future) and then consult the Virtueller Karlsruher catalogue to find the fitting research and academic articles to build on it perhaps. Otherwise, I fear, the scope and range would be too wide.
Is there already a specific focus this part or phase of the project "Critical Instruments" will have?"

## Related Artistic Examples

- [Critical Zones](https://zkm.de/en/exhibition/2020/05/critical-zones), especially [the field book](https://zkm.de/media/file/en/cz_fieldbook_digital_en.pdf)
- [Experiments in Arts and Economics](https://zkm.de/en/project/experiments-in-arts-and-economics)

## Links

- [Transformation Studies: Definitions, Approaches & Methods](https://www.umweltbundesamt.de/sites/default/files/medien/1410/publikationen/2017-11-08_texte_103-2017_transformationsforschung.pdf)
- [Workshop: Transformation Research – contents, goals and methods, 2016](https://www.ecologic.eu/13844)
- [Transformation Studies MA in Flensburg](https://www.uni-flensburg.de/studium-lehre/studienangebot/transformation#c125200)  
- [TU Berlin:transformation research group](https://www.tu.berlin/en/transformation/research/projects/digitalization-and-socio-ecological-transformation-research-group)