# New Cultural, New Instruments

every culture has it s own music, but it also builds it s own musical instruments. this is true for western and non-western cultures, for `RANDOM_ADJECTIVE` advanced and less advanced cultures, for ancient and modern cultures.

but what are today s and tomorrow musical ( self-built ) instruments? what kind of impetus can be inscribed into musical instruments and their mode of production? are ( historical ) muscial instruments the outcome of a certain culture or are they even shaping it? and what transformative power does this have?

this question gets a new spin when you look at *subcultures*. e.g what spin did the electric guitar give to punk music+culture or *Roland TB-303* to techno music+culture?
