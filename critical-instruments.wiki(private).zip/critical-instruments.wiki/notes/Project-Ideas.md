# Project Ideas

see also [google doc](https://docs.google.com/document/d/13NHGWi_B7Ter1VmWQQIToXdBR3Mmdz4tWIXlMgGW8T0)

- Open Source Community Driven Product Development
- Field Kit
- Books

## Open Source Community Driven Product Development

- making things locally
- *Roland 303 anecdote*
- *glocalization* ( do not like the buzzword but it can work in specific contexts )

## Field Kit

a set of *educated* artifacts and take it out into the *field*. see [[Field Kits]]

## Books

- publish a book to claim a field
- e.g CIID teachings in a composer space
