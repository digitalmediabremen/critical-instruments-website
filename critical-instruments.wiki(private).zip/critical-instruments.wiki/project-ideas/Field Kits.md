# Field Kits

- build a set of *educated* artifacts and take it out into the *field*
- for young people?
- https://koma-elektronik.com/?product=field-kit
- tools for [[Critical-Design-Ethnography]]
- an example of a *field kit* could be a device that allows to connect specific ( or arbitrary(?) ) sensors to a music-making *section* in order to sonify an environment ( see [Natalie Jeremijenko: Feral Robots](https://en.wikipedia.org/wiki/Natalie_Jeremijenko#Feral_Robots) [@Rhizome](https://rhizome.org/editorial/2006/aug/26/feral-robotic-dogs-natalie-jeremijenko/) ) #sonification @field_kit(sensor_sonification) %%<<< this is the working title of a field kit%%
- @todo(add some more examples)
